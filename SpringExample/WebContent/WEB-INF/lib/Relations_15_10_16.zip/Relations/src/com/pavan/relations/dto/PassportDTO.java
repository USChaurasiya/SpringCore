package com.pavan.relations.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="passport")
public class PassportDTO implements Serializable {
	public PassportDTO() {

	}

	@Id
	@GenericGenerator(name="automatic", strategy="increment")
	@GeneratedValue(generator="automatic")
	@Column(name="passport_id")
	private int passportId;
	@Column(name="citizenship")
	private String citizenship;
	@Column(name="validity")
	private Date validity;
	
	@OneToOne //java side relationship
	@JoinColumn(name="person_id") //db side relationship
	private PersonDTO personDTO;

	public int getPassportId() {
		return passportId;
	}

	public void setPassportId(int passportId) {
		this.passportId = passportId;
	}

	public String getCitizenship() {
		return citizenship;
	}

	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}

	public Date getValidity() {
		return validity;
	}

	public void setValidity(Date validity) {
		this.validity = validity;
	}

	public PersonDTO getPersonDTO() {
		return personDTO;
	}

	public void setPersonDTO(PersonDTO personDTO) {
		this.personDTO = personDTO;
	}

}
