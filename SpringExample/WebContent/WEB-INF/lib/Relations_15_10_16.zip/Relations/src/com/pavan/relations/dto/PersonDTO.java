package com.pavan.relations.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="person")
public class PersonDTO implements Serializable {
	public PersonDTO() {

	}
	@Id
	/*@GenericGenerator(name="auto", strategy="increment")
	@GeneratedValue(generator="auto")*/
	@Column(name="person_id")
	private int id;
	@Column(name="person_name")
	private String personName;
	@Column(name="age")
	private double age;
	@Column(name="phone_number")
	private long phoneNumber;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public double getAge() {
		return age;
	}

	public void setAge(double age) {
		this.age = age;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

}
