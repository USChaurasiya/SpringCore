package com.pavan.relations.tester;

import java.util.Calendar;
import java.util.Date;

import com.pavan.relations.dao.PassportDAO;
import com.pavan.relations.dao.PersonDAO;
import com.pavan.relations.dto.PassportDTO;
import com.pavan.relations.dto.PersonDTO;

public class AppTester {
	public static void main(String[] args) {
		PersonDTO personDTO = new PersonDTO();
		personDTO.setId(5);
		personDTO.setPersonName("qwery");
		personDTO.setAge(20.0);
		personDTO.setPhoneNumber(1223);
		
		PassportDTO passportDTO = new PassportDTO();
		passportDTO.setCitizenship("");
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, 2020);
		cal.set(Calendar.MONTH, Calendar.APRIL);
		cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		cal.set(Calendar.DATE, 20);
		passportDTO.setValidity(cal.getTime());
		passportDTO.setPersonDTO(personDTO);
		
		PersonDAO personDao = new PersonDAO();
		personDao.savePerson(personDTO);
		
		PassportDAO passportDAO = new PassportDAO();
		passportDAO.savePassport(passportDTO);
	}
}
